-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2023 at 03:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `travel_data`
--

CREATE TABLE `travel_data` (
  `username` varchar(50) NOT NULL,
  `tid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` text NOT NULL,
  `branch` text NOT NULL,
  `from_station` varchar(50) NOT NULL,
  `to_station` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `days_of_travel` int(20) NOT NULL,
  `Km_of_travel` int(100) NOT NULL,
  `rate` int(200) NOT NULL,
  `allowance_charges` int(200) NOT NULL,
  `lodging_charges` int(200) NOT NULL,
  `ticket_fare` int(200) NOT NULL,
  `convey_charges` int(200) NOT NULL,
  `total` int(110) DEFAULT NULL,
  `totalhour` int(11) NOT NULL,
  `Remark` text NOT NULL,
  `status` text NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel_data`
--

INSERT INTO `travel_data` (`username`, `tid`, `name`, `designation`, `branch`, `from_station`, `to_station`, `city`, `departure_time`, `arrival_time`, `days_of_travel`, `Km_of_travel`, `rate`, `allowance_charges`, `lodging_charges`, `ticket_fare`, `convey_charges`, `total`, `totalhour`, `Remark`, `status`, `application_date`) VALUES
('user', 1, 'Prasad Ingle', 'Officer', 'ADARSH COLONY, AKOLA', 'akola', 'shegaon', 'Nagpur', '17:39:00', '17:39:00', 12, 87, 97, 341, 647, 67, 6341, 7396, 24, 'ghcqsvvqsghvsqvshvjhqwvsjhvwqshvuhvwqsvkquwsv', 'Pending', '2023-08-31 12:09:37'),
('ash', 2, 'Prasad Ingle', 'Branch Head', 'MANGRULPIR ', 'Nagpur', 'shegaon', 'Nagpur', '17:43:00', '17:43:00', 12, 54, 8746, 54, 31, 3545, 4, 3634, 48, 'na', 'Pending', '2023-08-31 12:13:26'),
('', 3, 'kailash', 'Dy. CEO/Chief Manager', 'MAIN BRANCH, AKOLA', 'indore', 'mumbai', 'Metro City', '11:15:00', '11:15:00', 12, 54, 8, 98, 54, 874, 9, 12, 24, '', 'Pending', '2023-09-02 05:46:14'),
('', 4, 'kailash', 'Officer', 'KARANJA', 'indore', 'mumbai', 'Metro City', '11:19:00', '13:19:00', 56, 98, 95, 65, 32, 858, 26, 5, 26, 'na', 'Pending', '2023-09-02 05:49:36'),
('user', 5, 'kat', 'Dy. CEO/Chief Manager', 'TAJNAPETH, AKOLA', 'indore', 'karanja', 'Metro City', '11:21:00', '14:21:00', 54, 24, 26, 32, 4, 6, 8, 24, 27, '', 'Pending', '2023-09-02 05:52:08'),
('user', 6, 'AD', 'Dy. CEO/Chief Manager', 'MAIN BRANCH, AKOLA', 'KH', 'GF', 'Metro City', '12:09:00', '12:09:00', 4, 5, 45, 5, 6, 5, 6, 46, 24, '', 'Pending', '2023-09-02 06:39:54'),
('user', 7, 'AD', 'Dy. CEO/Chief Manager', 'TAJNAPETH, AKOLA', 'omkar', 'jalgaon', 'Metro City', '12:32:00', '12:32:00', 51, 4, 5, 2, 1, 3, 14, 54, 24, 'd', 'Pending', '2023-09-02 07:02:28'),
('user', 8, 'pro', 'Dy. CEO/Chief Manager', 'RAMDAS PETH, AKOLA', 'akola', 'bhusawal', 'Metro City', '15:39:00', '15:39:00', 25, 48, 65, 87, 4, 5, 8, 3, 24, '', 'Pending', '2023-09-02 10:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `create_date` varchar(50) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `username`, `email`, `mobile_number`, `password`, `create_date`, `role`) VALUES
(1, 'Test_user', 'admin', 'admin@gmail.com', '1215515', 'Test@123', '2023-08-10', ''),
(2, '', 'user', 'pdingle@gmail.com', '', 'Prasad@123', '2023-08-18 08:18:07', 'user'),
(7, '', 'prasad', 'prasad@gmail.com', '', 'Prasad@123', '2023-09-02 09:12:37', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `travel_data`
--
ALTER TABLE `travel_data`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `travel_data`
--
ALTER TABLE `travel_data`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
