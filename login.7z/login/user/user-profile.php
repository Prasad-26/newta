<?php
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');

$userid=$_GET['uid'];
$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))

{?>

                        <div class="card mb-4">
                        <!-- <h5 class="mt-2"><?php echo $result['name'];?>'s TA Bill</h5> -->
                            <div class="card-body">
                            <div class="Print">

                                <table class="table table-bordered table-secondary">
                                                              
                               
                                   <tr>
                                    <th>Name of Employee</th>
                                       <td><?php echo $result['name'];?></td>
                                   </tr>
                                
                                   <tr>
                                       <th>From Station</th>
                                       <td colspan="3"><?php echo $result['from_station'];?></td>
                                   </tr>
                                     <tr>
                                       <th>To Station</th>
                                       <td colspan="3"><?php echo $result['to_station'];?></td>
                                   </tr>
                                     
                                        <tr>
                                       <th>Departure Time</th>
                                       <td colspan="3"><?php echo $result['departure_time'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Arrival Time</th>
                                       <td colspan="3"><?php echo $result['arrival_time'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Days Of Travel</th>
                                       <td colspan="3"><?php echo $result['days_of_travel'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Kilometer of Travel</th>
                                       <td colspan="3"><?php echo $result['Km_of_travel'];?>&nbsp;km</td>
                                   </tr>
                                   <tr>
                                       <th>Rate</th>
                                       <td colspan="3">Rs.<?php echo $result['rate'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Allowance Charges</th>
                                       <td colspan="3">Rs.<?php echo $result['allowance_charges'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Lodging Charges</th>
                                       <td colspan="3">Rs.<?php echo $result['lodging_charges'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Ticket Fare</th>
                                       <td colspan="3">Rs.<?php echo $result['ticket_fare'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Conveyence Charges</th>
                                       <td colspan="3">Rs.<?php echo $result['convey_charges'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Total</th>
                                       <td colspan="3">Rs.<?php echo $result['total'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Remark</th>
                                       <td colspan="3"><?php echo $result['Remark'];?></td>
                                   </tr>
                                   <tr>
                                       <th>Status</th>
                                       <td colspan="3"><?php echo $result['status'];?></td>
                                   </tr>
                                   
                                    </tbody>

                                    
                                </table>
                              </div>

                                <tr >
                                 <td> <a href="edit .php?uid=<?php echo $result['tid'];?>" class="btn btn-success" >Edit TA Bill</a><td>
                                 <!-- <td>
                                <form method="post" action="">
                                <button type="submit" name="approved" class="btn btn-primary">Approve</button>
                                <button type="submit" name="rejected" class="btn btn-primary">Reject</button>
                                </form>
                                </td> -->
                                </tr>

                                <?php
                                // echo $userid;
                                if(isset($_POST['approved']))
                                {   
                                $query1=mysqli_query($con,"update travel_data SET status='Approved' where tid='$userid'");
                                echo "<meta http-equiv='refresh' content='0'>";
                                echo '<script type="text/javascript">alert("Approved")</script>';
                                }
                                if(isset($_POST['rejected']))
                                {
                                $query2=mysqli_query($con,"update travel_data SET status='Rejected' where tid='$userid'");
                                echo "<meta http-equiv='refresh' content='0'>";
                                echo '<script type="text/javascript">alert("Rejected")</script>';   
                                }
                                ?>    
                            
                            
                           
                            </div>
                        </div>

                        
<?php 
} 
?>
                    


                    </div>
                </main>
                
            </div>
        </div>
      
        

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
