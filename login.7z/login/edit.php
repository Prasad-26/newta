<?php
include("header.php");
include("common/auth_session.php");
require('common/db.php');


//Code for Updation 
if(isset($_POST['update']))
{
    $name = $_POST['name'];
    $doj = $_POST['Doj'];
    $fromSation = $_POST['fromSation'];
    $toSataion = $_POST['toSataion'];
    $Tod = $_POST['Tod'];
    $Toa = $_POST['Toa'];
    $daysOfTravel = $_POST['daysOfTravel'];
    $kmOfTravel = $_POST['kmOfTravel'];
    $rate = $_POST['rate'];
    $daliyAllowanceCharges = $_POST['daliyAllowanceCharges'];
    $lodgingCharges = $_POST['lodgingCharges'];
    $ticketFare = $_POST['ticketFare'];
    $conveyCharges = $_POST['conveyCharges'];
    $total = $_POST['total'];
    $remark = $_POST['remark'];
    $city = $_POST['city'];
    $branch = $_POST['branch'];
    $userid=$_GET['uid'];

echo $total = $daliyAllowanceCharges + $lodgingCharges +  $ticketFare +  $conveyCharges;

    $msg=mysqli_query($con,"update travel_data set name='$name',branch='$branch',doj='$doj',from_station='$fromSation',city='$city',to_station = '$toSataion',departure_time = '$Tod',arrival_time='$Toa',days_of_travel='$daysOfTravel',Km_of_travel='$kmOfTravel',rate='$rate',allowance_charges='$daliyAllowanceCharges',lodging_charges='$lodgingCharges',ticket_fare='$ticketFare',convey_charges='$conveyCharges',total='$total',Remark='$remark' where tid='$userid'");
    echo mysqli_affected_rows($con);
if($msg)
{
       echo "<script>alert('Travel Bill updated successfully');</script>";
       echo "<script type='text/javascript'> document.location = 'manage_user.php'; </script>";
    
}
else{
   echo "Error: " . $msg . "<br>" . mysqli_error($con);
}
}


?>

<?php 
$userid=$_GET['uid'];
$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))
{
   ?>

<div class="container">
    <div class="form">
      <h5 class="text-center">Update Travel Bill Details</h5>
      <hr>  
     
    <form method="POST" action="#">
                        <div class="row">
                             <div class="col">
                               <label for="exampleFormControlInput1" class="form-label">Name of Employee</label>
                               <input type="text" class="form-control" name="name" placeholder="Name of Employee" value="<?php echo $result['name'];?>" aria-label="First name" required>
                                </div>
                                <div class="col">                          
                               <select class="form-select" aria-label="First Name" name='branch' required>   
                                  <option value="pick">Select Branch</option>
                           <?php
                           $sql = mysqli_query($con, "SELECT * From branches");
                           $row = mysqli_num_rows($sql);
                           while ($row = mysqli_fetch_array($sql)){
                           echo "<option value='". $row['br_id'] ."'>" .$row['br_name'] ."</option>";
                            }
                            ?>
                          </select>
                          </div>
                                <div class="col">
                                <label for="exampleFormControlInput1" class="form-label">Date of Jurney</label>
                               <input type="date" class="form-control" name="Doj" placeholder="Date of Jurney" value="<?php echo $result['doj'];?>" aria-label="First name" required>
                                </div>
                            <div class="col">
                            <label for="exampleFormControlInput1" class="form-label">From Station</label>
                               <input type="text" class="form-control" name="fromSation" placeholder="From Station" value="<?php echo $result['from_station'];?>" aria-label="Last name" required>
                             </div>
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">To Station</label>
                                <input type="text" class="form-control" name="toSataion" placeholder="To Station" value="<?php echo $result['to_station'];?>" aria-label="Last name" required>
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Time of Departure</label>
                                <input type="time" class="form-control" name="Tod" placeholder="Time Of Departure" value="<?php echo $result['departure_time'];?>" aria-label="First name" required>
                             </div>
                            <div class="col">
                            <label for="exampleFormControlInput1" class="form-label">Time of Arrival</label>
                               <input type="time" class="form-control" name="Toa" placeholder="Time Of Arrival" value="<?php echo $result['arrival_time'];?>" aria-label="Last name" required>
                             </div>
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Days of Travel</label>
                               <input type="number" class="form-control" name="daysOfTravel" placeholder="Total Days of Travel" value="<?php echo $result['days_of_travel'];?>" aria-label="Last name" required>
                             </div>
                             <div class="col">  
                             <label for="exampleFormControlInput1" class="form-label"> Travlling City</label>                        
                               <select class="form-select" aria-label="First Name" name='city' required>   
                                  <option value="pick">Select City</option>
                                    <?php
                                        $sql = mysqli_query($con, "SELECT * From city");
                                        $row = mysqli_num_rows($sql);
                                        while ($row = mysqli_fetch_array($sql)){
                                            echo "<option value='". $row['c_id'] ."'>" .$row['city_name'] ."</option>";
                                           }
                                      ?>
                          </select>
                          </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Kilo Meters of Travel</label>
                                <input type="number" class="form-control" name="kmOfTravel" placeholder="Total Kilo-Meters of Travel" value="<?php echo $result['Km_of_travel'];?>" aria-label="First name" required>
                             </div>
                            <div class="col">
                            <label for="exampleFormControlInput1" class="form-label">Rate</label>
                               <input type="number" class="form-control" name="rate" placeholder="Rate" value="<?php echo $result['rate'];?>"  aria-label="Last name">
                             </div>
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Daily Allowance Charges</label>
                               <input type="number" class="form-control" id="dac" name="daliyAllowanceCharges" value="<?php echo $result['allowance_charges'];?>" placeholder="Daily Allowance Charges" onChange="chargesTotal()" aria-label="Last name" required>
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Lodging Charges</label>
                                <input type="number" class="form-control" id="lc" name="lodgingCharges" placeholder="Lodging Charges" value="<?php echo $result['lodging_charges'];?>" onChange="chargesTotal()" aria-label="First name" required>
                             </div>
                            <div class="col">
                            <label for="exampleFormControlInput1" class="form-label">Ticket Fare</label>
                               <input type="number" class="form-control" id="tf" name="ticketFare" placeholder="Ticket Fare" value="<?php echo $result['ticket_fare'];?>" onChange="chargesTotal()" aria-label="Last name" required>
                             </div>
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Conveyence Charges</label>
                               <input type="number" class="form-control" id="cc" name="conveyCharges" placeholder="Convey Charges" value="<?php echo $result['convey_charges'];?>" onChange="chargesTotal()" aria-label="Last name" required> 
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                             <label for="exampleFormControlInput1" class="form-label">Total</label>
                                <input type="text" class="form-control" id="total" name="total" placeholder="Total" value="<?php echo $result['total'];?>" aria-label="First name" required>
                             </div>
                            <div class="col">
                            <label for="exampleFormControlInput1" class="form-label">Remark</label>
                               <input type="text" class="form-control" name="remark" placeholder="Remark (if any)" value="<?php echo $result['Remark'];?>" aria-label="Last name">
                             </div><br><br><br>
                         
                            <div class="row">
                            <div class="col">
                                <button class="btn btn-primary" name="update" id="btn" >Update Data</button>
                                <a class="btn btn-primary" href="manage_user.php" name="update" id="btn" >Back</a>
                             </div>
                            </div>
                        </form> 
                        <?php } ?>
    </div>
   </div>
   <script>
   function chargesTotal(){
       var value_1 = document.getElementById('dac').value;
       var value_2 = document.getElementById('lc').value;
       var value_3 = document.getElementById('tf').value;
       var value_4 = document.getElementById('cc').value;
       var total = Number(value_1) + Number(value_2) + Number(value_3) + Number(value_4);
       var displaySum = document.getElementById('total');
           displaySum.value = total;
       //alert(total);
    }
</script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>