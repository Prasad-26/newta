<?php
header("Location: common/login.php");
?>
