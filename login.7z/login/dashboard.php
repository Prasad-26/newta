<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("common/auth_session.php");
require('common/db.php');

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    // $doj = $_POST['Doj'];
    $fromSation = $_POST['fromSation'];
    $toSataion = $_POST['toSataion'];
    $Tod = $_POST['Tod'];
    $Toa = $_POST['Toa'];
    $daysOfTravel = $_POST['daysOfTravel'];
    $kmOfTravel = $_POST['kmOfTravel'];
    $rate = $_POST['rate'];
    $daliyAllowanceCharges = $_POST['daliyAllowanceCharges'];
    $lodgingCharges = $_POST['lodgingCharges'];
    $ticketFare = $_POST['ticketFare'];
    $conveyCharges = $_POST['conveyCharges'];
    $total = $_POST['total'];
    $totalhour=$_POST['totalhour'];
    $remark = $_POST['remark'];
   
    
    
    
    echo print_r($_POST);

   $query = "insert into travel_data (name,
             from_station,
             to_station,
             departure_time,
             arrival_time,
             days_of_travel,
             Km_of_travel,
             rate,
             allowance_charges,
             lodging_charges,
             ticket_fare,
             convey_charges,
             total,totalhour,
        Remark) 
values('$name','$fromSation','$toSataion','$Tod','$Toa','$daysOfTravel','$kmOfTravel','$rate','$daliyAllowanceCharges','$lodgingCharges','$ticketFare','$conveyCharges','$total','$totalhour','$remark')";
         
if (mysqli_query($con, $query)) {
      $msg = "New record created successfully";
      echo '<script>alert($msg);</script>';
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($con);
    
}
  

$target_path = "tickets/";
$target_path = $target_path.basename( $_FILES['fileToUpload']['name']);  

  if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
    echo "File uploaded successfully!";  
} else{  
    echo "Sorry, file not uploaded, please try again!";  
}

// if ($_FILES["fileToUpload"]["size"] > 500000) {
//   echo "Sorry, your file is too large.";
//   $uploadOk = 0;
// }

$target_path = "lodgingbills/";
$target_path = $target_path.basename( $_FILES['fileUpload']['name']);  

  if(move_uploaded_file($_FILES['fileUpload']['tmp_name'], $target_path)) {  
    echo "File uploaded successfully!";  
} else{  
    echo "Sorry, file not uploaded, please try again!";  
}

header("Location:manage_user.php");


}




?>

    <div class="container">
    <div class="form">
      <h5 class="text-center">Enter Travel Bill Details</h5>
      <hr>  
     
    <form method="POST" action="#" enctype="multipart/form-data">
                        <div class="row">
                             <div class="col">
                               <input type="text" class="form-control" name="name" placeholder="Name of Employee" aria-label="First name" required>
                                </div>
                                <!-- <div class="col">
                               <input type="datetime-local" class="form-control" name="Doj" placeholder="Date of Jurney" aria-label="First name" required>
                                </div> -->
                            <div class="col">
                               <input type="text" class="form-control" name="fromSation" placeholder="From Station" aria-label="Last name" required>
                             </div>
                             <div class="col">
                                <input type="text" class="form-control" name="toSataion" placeholder="To Station" aria-label="Last name" required>
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                                <input type="datetime-local" class="form-control" id="Tod" name="Tod" placeholder="Time Of Diparture" aria-label="First name" required>
                             </div>
                            <div class="col">
                               <input type="datetime-local" class="form-control" id="Toa" name="Toa" placeholder="Time Of Arrival" aria-label="Last name" onChange="myFunction()" required>
                             </div>
                             <div class="col">
                               <input type="number" class="form-control" name="daysOfTravel" placeholder="Total Days of Travel" aria-label="Last name" required>
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                                <input type="number" class="form-control" name="kmOfTravel" placeholder="Total Kilo-Meters of Travel" aria-label="First name" required>
                             </div>
                            <div class="col">
                               <input type="number" class="form-control" name="rate" placeholder="Rate" aria-label="Last name">
                             </div>
                             <div class="col">
                               <input type="number" class="form-control" id="dac" name="daliyAllowanceCharges" placeholder="Daily Allowance Charges" aria-label="Last name" required>
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                                <input type="number" class="form-control" id="lc" name="lodgingCharges" placeholder="Lodging Charges" aria-label="First name" required>
                             </div>
                            <div class="col">
                               <input type="number" class="form-control" id="tf" name="ticketFare" placeholder="Ticket Fare" aria-label="Last name" required>
                             </div>
                             <div class="col">
                               <input type="number" class="form-control" id="cc" name="conveyCharges" placeholder="Convey Charges" onChange="chargesTotal()" aria-label="Last name" required> 
                             </div>
                            </div><br>
                            <div class="row">
                             <div class="col">
                                <input type="text" class="form-control" id="total" name="total" placeholder="Total" aria-label="First name" required>
                             </div>
                             <div class="col">
                                <input type="text" class="form-control" id="totalhour" name="totalhour" placeholder="Totalhour" aria-label="First name" >
                             </div>
                            <div class="col">
                               <input type="text" class="form-control" name="remark" placeholder="Remark (if any)" aria-label="Last name">
                             </div><br><br>
                             <div class="col">
                                <input  type="file" id="fileToUpload" name="fileToUpload"/>
                               <label for="img">Upload Tickets Here</label> 
                             </div>
                             <div class="col">
                                <input  type="file" id="fileUpload" name="fileUpload"/>
                               <label for="img">Upload Lodging Bills Here</label> 
                             </div>
                             </div><br> 
                            <div class="row">
                            <div class="col">
                                <button class="btn btn-primary" name="submit" id="btn" >Submit</button>
                             </div>
                            </div>
                        </form> 
    </div>
   </div>

   <!-- Java Script Get Started From here -->
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  
  <script>
   function chargesTotal(){
       var value_1 = document.getElementById('dac').value;
       var value_2 = document.getElementById('lc').value;
       var value_3 = document.getElementById('tf').value;
       var value_4 = document.getElementById('cc').value;
       var total = Number(value_1) + Number(value_2) + Number(value_3) + Number(value_4);
       var displaySum = document.getElementById('total');
           displaySum.value = total;
       //alert(total);
    }
 </script>

<script>
  //  function totalhr(){
  //      var value_1 = document.getElementById('Tod').value;
  //      var value_2 = document.getElementById('Toa').value;
  //      $hourdiff = round((strtotime($time1) - strtotime($time2))/3600, 1);   
  //             var displayTime = document.getElementById('totalhour');
  //          displayTime.value = hourdiff;
           
  //     //  alert(value1);
  //   }

  document.querySelector("#Toa").addEventListener("change", myFunction);

function myFunction() {

  //value start
  var start = Date.parse($("input#Tod").val()); //get timestamp

  //value end
  var end = Date.parse($("input#Toa").val()); //get timestamp

  totalHours = NaN;
  if (start < end) {
    totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60
  }

  $("#totalhour").val(totalHours);

}
</script>





<script>
  var km = "180";
  var totaltime = "13";
  var desg  = "ceo";
  var city  = "nagpur";
 if(desg == "ceo" && city =="nagpur"){
 
  if(km < "200"){
     
      if(totaltime < "6"){
        //alert("applicable for conv is 100");

      }
      if(totaltime >= "6" && totaltime < "12" ){
        //alert("applicable for DA & conv");

      }
      if(totaltime >= "12" ){
        //alert("applicable for DA, Lodging & conv");

      }
  }
}


</script>
</body>
</html>
