-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2023 at 02:55 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `main_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `travel_data`
--

CREATE TABLE `travel_data` (
  `tid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `doj` date NOT NULL,
  `from_station` varchar(50) NOT NULL,
  `to_station` varchar(50) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `days_of_travel` int(20) NOT NULL,
  `Km_of_travel` int(100) NOT NULL,
  `rate` int(200) NOT NULL,
  `allowance_charges` int(200) NOT NULL,
  `lodging_charges` int(200) NOT NULL,
  `ticket_fare` int(200) NOT NULL,
  `convey_charges` int(200) NOT NULL,
  `total` int(110) DEFAULT NULL,
  `Remark` text NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travel_data`
--

INSERT INTO `travel_data` (`tid`, `name`, `doj`, `from_station`, `to_station`, `departure_time`, `arrival_time`, `days_of_travel`, `Km_of_travel`, `rate`, `allowance_charges`, `lodging_charges`, `ticket_fare`, `convey_charges`, `total`, `Remark`, `application_date`) VALUES
(1, 'Saurabh b ', '0000-00-00', 'akola', 'amravati', '03:00:00', '04:00:00', 5, 100, 100, 50, 200, 100, 50, 0, 'NA', '2023-08-10 11:40:31'),
(2, 'Saurabh b ', '0000-00-00', 'akola', 'amravati', '03:00:00', '04:00:00', 5, 100, 100, 50, 200, 100, 50, 0, 'NA', '2023-08-10 11:40:47'),
(3, 'Amol b', '2023-08-11', 'akola', 'nagpur', '01:00:00', '02:00:00', 10, 200, 100, 20, 50, 100, 20, 190, 'na', '2023-08-10 11:41:37');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_number` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `create_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `username`, `email`, `mobile_number`, `password`, `create_date`) VALUES
(1, 'Test_user', 'admin', 'admin@gmail.com', '1215515', 'Test@123', '2023-08-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `travel_data`
--
ALTER TABLE `travel_data`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `travel_data`
--
ALTER TABLE `travel_data`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
